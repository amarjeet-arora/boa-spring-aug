package com.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.entity.Cart;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Product;
import com.model.ShoppingCartRequest;
import com.model.ShoppingCartResponse;
import com.repo.CartRepo;

@Service
public class ShoppingService {
	@Autowired
	@Qualifier("webclient")
	private WebClient.Builder builder;
	@Autowired
	private CartRepo repo;
	public ShoppingCartResponse processAndRequest(Long userId,List<ShoppingCartRequest> shoppingCartRequestList) {
		//call Product API
		ObjectMapper mapper= new ObjectMapper();
		String productServiceURL= "http://product-service/products/getproducts/"+shoppingCartRequestList.stream()
		.map(e -> String.valueOf(e.getProductId())).collect(Collectors.joining(","));
		List<Product> productServiceList= builder.build()
				.get()
				.uri(productServiceURL)
				.retrieve()
				.bodyToFlux(Product.class)
				.collectList()
				.block();
		System.out.println(productServiceURL);
		System.out.println(productServiceList);
		
		//calculate cart Total cost
		final Double[] totalCost= {0.0};
		productServiceList.forEach(psl -> {
			shoppingCartRequestList.forEach(scr -> {
				if(psl.getProductId() == scr.getProductId()) {
					psl.setQuantity(scr.getQuantity());
					totalCost[0] =totalCost[0] +psl.getAmount() *scr.getQuantity();
				}
			});
		});
		//create cartEntity
		Cart cartEntity =null;
		try {
			cartEntity= Cart.builder()
					.userId(userId)
					.cartId((long) (Math.random()*Math.pow(10, 10)))
					.totalItems(productServiceList.size())
					.totalCosts(totalCost[0])
					.products(mapper.writeValueAsString(productServiceList))
					.build();
			
		}catch (Exception e) {}
		//save cart in DB
		cartEntity=repo.save(cartEntity);
		// create and return response...
		
		ShoppingCartResponse response= ShoppingCartResponse.builder()
				.cartId(cartEntity.getCartId())
				.userId(cartEntity.getUserId())
				.totalItems(cartEntity.getTotalItems())
				.totalCosts(cartEntity.getTotalCosts())
				.products(productServiceList)
				.build();
		
		return response;
	}
}
