package com.example.shoppingregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
